/============================================================================\
| YAXGL 0.9 Prerelease Demo                                                  |
\============================================================================/

This is the 0.9 prerelease demo. There are still a lot of features missing
and not that much error checking. Have a look on http://www.yaxgl.de/ for
updates.

Remarks:
- For the .NET version to compile, you need to adjust the path to your Visual
  Studio bin/ directory in dotnet/run.bat. (Or alternatively, have csc.exe in
  your path or execute the vcvars32.bat beforehand, then call may fail then.)
- For the Python/wxWidgets version to run, you are required to have wxWidgets
  and the Python version of the YAXGL library installed. The download can
  be found on the website.
  
  
  
Thanks for testing,
  the YAXGL team
  

==> http://www.yaxgl.de/
/============================================================================\
| YAXGL (Python/wxWidgets) 0.9 Prerelease                                    |
\============================================================================/

This is the 0.9 prerelease demo. There are still a lot of features missing
and not that much error checking. Have a look on http://www.yaxgl.de/ for
updates.

Installation:
- This library is wrapping wxPython, so you need to have wxPython installed.
  (http://www.wxpython.org/)
- Copy the contents of this archive into your %PYTHON%/lib/site-packages
  directory, i.e. you should end up with something like:
  c:\Python\\lib\site-packages\de\yaxgl\...

from de.yaxgl.Helper.Python.Enum import Enum

NativeGuiFramework = Enum(
        "wxWidgets"
    )

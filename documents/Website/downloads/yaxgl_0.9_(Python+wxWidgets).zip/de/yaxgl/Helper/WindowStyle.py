from de.yaxgl.Helper.Python.Enum import Enum

WindowStyle = Enum(
        "Fixed",
        "Sizeable",
        "none"
    )

class Location:
    def __init__(self, xpos=0, ypos=0):
        self.xpos = xpos
        self.ypos = ypos
        
    def getXPos(self):
        return(self.xpos)
    
    def getYPos(self):
        return(self.ypos)
    
    def setXPos(self, xpos):
        self.xpos = xpos
        
    def setYPos(self, ypos):
        self.ypos = ypos

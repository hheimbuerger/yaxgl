from de.yaxgl.Helper.Python.Enum import Enum

LookAndFeel = Enum(
        "System"
    )

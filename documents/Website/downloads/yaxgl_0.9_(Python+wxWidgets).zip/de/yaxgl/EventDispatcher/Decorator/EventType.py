from de.yaxgl.Helper.Python.Enum import Enum

EventType = Enum(
        "Any",
        "Click",
        "GotFocus",
        "LostFocus",
        "SelectionChanged"
    )

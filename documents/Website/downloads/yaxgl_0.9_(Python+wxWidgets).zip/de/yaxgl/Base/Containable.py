pass

# Python, being a dynamically typed language, doesn't need this interface at all.
# The file is just here to keep the library consistent with the other versions
# and to spread the news. ;)
